import React, { useEffect, useMemo, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { areas, defaultAnswers, getCommute, money, monthlyCost, rankAreas, type Answers, type Area, type Destination, type FoodPreference, type HomeType, type Lifestyle } from './src/logic';
import { Button, C, Card, Eyebrow, Icon, Row, SectionTitle } from './src/ui';
import { citiesFor, currencyFor, places, universitiesFor } from './src/places';
import { BrandLogo } from './src/brand';
import { budgetInDestination, fetchExchangeRate } from './src/fx';

type Screen = 'auth' | 'home' | 'quiz' | 'results' | 'area' | 'compare' | 'addArea' | 'booking' | 'move' | 'settle' | 'kit' | 'circle' | 'rep' | 'report';
type Booking = { id: number; areaId: string; address: string; time: string; questions: string; status: 'open' | 'accepted' | 'complete'; rep?: string; report?: string; notes?: string };

const quizSteps = [
  { title: 'Which country are you moving to?', subtitle: 'Choose your study destination first.' },
  { title: 'Which city will you call home?', subtitle: 'Pick a city or enter any destination worldwide.' },
  { title: 'Where will you study?', subtitle: 'Choose your university from the list or enter another one.' },
  { title: 'Where are you coming from?', subtitle: 'Tell us your home country so we can make your move feel more familiar.' },
  { title: 'Which currency feels familiar?', subtitle: 'Choose the currency you use every day.' },
  { title: 'Live alone or share?', subtitle: 'Choose the kind of home you want to compare.' },
  { title: 'What is your rent budget?', subtitle: 'Enter it in your currency. We’ll show the equivalent where you’re moving.' },
  { title: 'How often will you travel?', subtitle: 'This shapes your transport estimate.' },
  { title: 'What feels familiar?', subtitle: 'Small everyday details help a place feel like home.' },
  { title: 'What is your kind of weekend?', subtitle: 'Pick the one that matters most.' },
];

const commonCurrencies = ['GBP', 'USD', 'EUR', 'CAD', 'AUD', 'JPY', 'KRW', 'SGD', 'AED', 'UZS'];

const settleTasks = [
  { id: 'evisa', title: 'Check your eVisa details', subtitle: 'Review your status on the official UK service.', icon: 'document-text-outline' as const },
  { id: 'gp', title: 'Register with a GP', subtitle: 'Find a surgery close to your new address.', icon: 'medical-outline' as const },
  { id: 'bank', title: 'Set up a bank account', subtitle: 'Gather the documents your provider requests.', icon: 'card-outline' as const },
  { id: 'ni', title: 'Check if you need an NI number', subtitle: 'Requirements depend on your work situation.', icon: 'briefcase-outline' as const },
  { id: 'council', title: 'Check council tax status', subtitle: 'Your eligibility depends on your circumstances.', icon: 'home-outline' as const },
];
const globalSettleTasks = [
  { id: 'entry', title: 'Check entry and residence steps', subtitle: 'Use the official guidance for your destination.', icon: 'document-text-outline' as const },
  { id: 'health', title: 'Find local healthcare', subtitle: 'Check registration and insurance requirements.', icon: 'medical-outline' as const },
  { id: 'bank', title: 'Plan a local payment method', subtitle: 'Compare providers and required documents.', icon: 'card-outline' as const },
  { id: 'transport', title: 'Set up your commute', subtitle: 'Check fares and passes for your route.', icon: 'train-outline' as const },
  { id: 'home', title: 'Confirm home setup', subtitle: 'Utilities, local taxes and move-in access vary.', icon: 'home-outline' as const },
];

const basicItems = ['Duvet & pillow', 'Bed linen', 'Towel', 'Kettle'];
const comfortItems = [...basicItems, 'Pan & utensils', 'Crockery', 'Lamp', 'Hangers'];

function Choice({ label, selected, onPress, detail, icon }: { label: string; selected: boolean; onPress: () => void; detail?: string; icon?: keyof typeof Ionicons.glyphMap }) {
  return <Pressable onPress={onPress} style={[s.choice, selected && s.choiceSelected]}>
    {icon && <View style={s.choiceIcon}><Icon name={icon} size={20} color={C.green} /></View>}
    <View style={{ flex: 1 }}><Text style={[s.choiceLabel, selected && { color: C.green }]}>{label}</Text>{detail && <Text style={s.choiceDetail}>{detail}</Text>}</View>
    <Icon name={selected ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={selected ? C.green : '#B9C7BE'} />
  </Pressable>;
}

function CostRows({ area, answers }: { area: Area; answers: Answers }) {
  const cost = monthlyCost(area, answers);
  const familiarTotal = answers.preferredCurrency !== answers.currency && answers.exchangeRate > 0
    ? money(cost.total * answers.exchangeRate, answers.preferredCurrency) : null;
  return <View style={{ gap: 11 }}>
    {[
      ['Rent', cost.rent], ['Estimated bills', cost.bills], ['Estimated commute', cost.transport],
      ['Local tax assumption', cost.councilTax],
    ].map(([label, value]) => <View key={String(label)} style={s.costRow}><Text style={s.muted}>{label}</Text><Text style={s.costValue}>{money(Number(value), answers.currency)}</Text></View>)}
    <View style={s.divider} />
    <View style={s.costRow}><Text style={s.totalLabel}>Estimated per month</Text><Text style={s.totalValue}>{money(cost.total, answers.currency)}</Text></View>
    {familiarTotal && <Text style={s.familiarCost}>About {familiarTotal} in your familiar currency · reference rate</Text>}
  </View>;
}

function AppContent() {
  const scrollRef = useRef<ScrollView>(null);
  const [screen, setScreen] = useState<Screen>('auth');
  const [authType, setAuthType] = useState<'email' | 'phone' | 'google' | 'microsoft'>('email');
  const [authValue, setAuthValue] = useState('');
  const [authError, setAuthError] = useState('');
  const [rateStatus, setRateStatus] = useState<'idle' | 'same' | 'loading' | 'ready' | 'error'>('idle');
  const [rateDate, setRateDate] = useState('');
  const [rateRetry, setRateRetry] = useState(0);
  const [budgetInput, setBudgetInput] = useState('');
  const [answers, setAnswers] = useState<Answers>(defaultAnswers);
  const [customAreas, setCustomAreas] = useState<Area[]>([]);
  const [quizStep, setQuizStep] = useState(0);
  const [selectedAreaId, setSelectedAreaId] = useState('fulham');
  const [newAreaName, setNewAreaName] = useState('');
  const [newAreaRent, setNewAreaRent] = useState('');
  const [newAreaBills, setNewAreaBills] = useState('');
  const [newAreaFare, setNewAreaFare] = useState('');
  const [newAreaCommute, setNewAreaCommute] = useState('');
  const [newAreaTax, setNewAreaTax] = useState('');
  const [areaError, setAreaError] = useState('');
  const [address, setAddress] = useState('');
  const [time, setTime] = useState('');
  const [questions, setQuestions] = useState('');
  const [bookingError, setBookingError] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [reportBookingId, setReportBookingId] = useState<number | null>(null);
  const [reportText, setReportText] = useState('');
  const [reportNotes, setReportNotes] = useState('');
  const [doneTasks, setDoneTasks] = useState<string[]>([]);
  const [kitSelection, setKitSelection] = useState<'Basic' | 'Comfort'>('Basic');
  const [kitRequested, setKitRequested] = useState(false);
  const [showRep, setShowRep] = useState(false);

  useEffect(() => { scrollRef.current?.scrollTo({ y: 0, animated: false }); }, [screen, quizStep]);
  useEffect(() => {
    const base = answers.currency.toUpperCase();
    const quote = answers.preferredCurrency.toUpperCase();
    if (!/^[A-Z]{3}$/.test(base) || !/^[A-Z]{3}$/.test(quote)) {
      setRateStatus('idle'); setRateDate(''); setAnswers(prev => ({ ...prev, exchangeRate: 0 })); return;
    }
    if (base === quote) {
      setRateStatus('same'); setRateDate(''); setAnswers(prev => ({ ...prev, exchangeRate: 1 })); return;
    }
    const controller = new AbortController();
    let active = true;
    const timeout = setTimeout(() => controller.abort(), 8000);
    setRateStatus('loading'); setRateDate(''); setAnswers(prev => ({ ...prev, exchangeRate: 0 }));
    fetchExchangeRate(base, quote, controller.signal).then(rate => {
      if (!active) return;
      setAnswers(prev => prev.currency === base && prev.preferredCurrency === quote ? { ...prev, exchangeRate: rate.rate } : prev);
      setRateDate(rate.date); setRateStatus('ready');
    }).catch(() => {
      if (!active) return;
      setRateStatus('error'); setRateDate('');
    }).finally(() => clearTimeout(timeout));
    return () => { active = false; clearTimeout(timeout); controller.abort(); };
  }, [answers.currency, answers.preferredCurrency, rateRetry]);

  const budgetRate = answers.currency === answers.preferredCurrency ? 1 : rateStatus === 'ready' ? answers.exchangeRate : 0;
  const convertedBudget = budgetInDestination(Number(budgetInput), budgetRate);
  useEffect(() => {
    setAnswers(prev => prev.budget === convertedBudget ? prev : { ...prev, budget: convertedBudget });
  }, [convertedBudget]);

  const allAreas = useMemo(() => [...areas, ...customAreas], [customAreas]);
  const ranked = useMemo(() => rankAreas(answers, answers.country === 'United Kingdom' ? allAreas : customAreas), [answers, allAreas, customAreas]);
  const selectedArea = allAreas.find(area => area.id === selectedAreaId) ?? ranked[0]?.area ?? areas[0];
  const activeBooking = bookings.find(booking => booking.id === reportBookingId);
  const activeSettleTasks = answers.country === 'United Kingdom' ? settleTasks : globalSettleTasks;
  const completedTasks = activeSettleTasks.filter(item => doneTasks.includes(item.id)).length;

  const go = (next: Screen) => setScreen(next);
  const updateAnswer = <K extends keyof Answers>(key: K, value: Answers[K]) => setAnswers(prev => ({ ...prev, [key]: value }));
  const setFamiliarCurrency = (code: string) => {
    setRateStatus(code.length !== 3 ? 'idle' : code === answers.currency ? 'same' : 'loading');
    setRateDate('');
    setAnswers(prev => ({ ...prev, preferredCurrency: code, exchangeRate: 0 }));
  };
  const startQuiz = () => { setQuizStep(0); go('quiz'); };
  const continueAuth = () => {
    if (authType === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(authValue.trim())) { setAuthError('Enter a valid email address to preview this path.'); return; }
    if (authType === 'phone' && authValue.replace(/\D/g, '').length < 7) { setAuthError('Enter a phone number with at least 7 digits.'); return; }
    setAuthError(''); startQuiz();
  };
  const selectArea = (areaId: string, next: Screen = 'area') => { setSelectedAreaId(areaId); go(next); };
  const saveArea = () => {
    const rent = Number(newAreaRent); const bills = Number(newAreaBills); const fare = Number(newAreaFare);
    const commute = Number(newAreaCommute); const tax = Number(newAreaTax || '0');
    if (!newAreaName.trim() || !newAreaRent.trim() || !newAreaBills.trim() || !newAreaFare.trim() || !newAreaCommute.trim() ||
        ![rent, bills, fare, commute, tax].every(Number.isFinite) || rent <= 0 || bills < 0 || fare < 0 || commute < 0 || tax < 0) {
      setAreaError('Add an area name and valid non-negative cost and commute figures.'); return;
    }
    const item: Area = {
      id: `custom-${Date.now()}`, city: answers.city.trim(), name: newAreaName.trim(), zone: 'Your estimate',
      character: `Your own cost comparison for ${answers.city.trim()}.`, roomRent: rent, soloRent: rent,
      farePerTrip: fare, manualCommute: commute, billsShared: bills, billsSolo: bills, localTax: tax,
      commute: { imperial: commute, ucl: commute, kings: commute, lse: commute },
      food: [], lifestyle: [], accent: '#DFECE5', icon: 'location-outline',
    };
    setCustomAreas(prev => [...prev, item]); setNewAreaName(''); setNewAreaRent(''); setNewAreaBills('');
    setNewAreaFare(''); setNewAreaCommute(''); setNewAreaTax(''); setAreaError(''); go('results');
  };
  const submitBooking = () => {
    if (!address.trim() || !time.trim()) { setBookingError('Add a listing address and a time window to continue.'); return; }
    setBookings(prev => [{ id: Date.now(), areaId: selectedAreaId, address: address.trim(), time: time.trim(), questions: questions.trim(), status: 'open' }, ...prev]);
    setAddress(''); setTime(''); setQuestions(''); setBookingError(''); go('move');
  };
  const acceptBooking = (id: number) => setBookings(prev => prev.map(item => item.id === id ? { ...item, status: 'accepted', rep: 'You' } : item));
  const saveReport = () => {
    if (!reportText.trim() || reportBookingId === null) return;
    setBookings(prev => prev.map(item => item.id === reportBookingId ? { ...item, status: 'complete', report: reportText.trim(), notes: reportNotes.trim() } : item));
    setReportText(''); setReportNotes(''); setReportBookingId(null); go('rep');
  };

  const header = <View style={s.header}>
    <Pressable disabled={screen === 'quiz'} onPress={() => go(showRep ? 'rep' : 'home')} style={s.brand}><BrandLogo size={34} /><Text style={s.brandText}>nooks<Text style={{ color: C.orange }}>.</Text></Text></Pressable>
    {screen !== 'quiz' && <Pressable onPress={() => { setShowRep(!showRep); go(!showRep ? 'rep' : 'home'); }} style={s.modePill}>
      <Text style={s.modeText}>{showRep ? 'REP MODE' : 'DEMO APP'}</Text><Icon name="swap-horizontal" size={15} color={C.green} />
    </Pressable>}
  </View>;

  const auth = <View style={s.authWrap}>
    <View style={s.authHalo} />
    <View style={{ marginBottom: 16 }}><BrandLogo size={74} /></View>
    <Text style={s.authBrand}>nooks</Text>
    <Eyebrow>YOUR NEW CITY STARTS HERE</Eyebrow>
    <Text style={s.authTitle}>A familiar face, wherever you go.</Text>
    <Text style={s.authSubtitle}>Create your space, then tell us where you’re studying. We’ll help you find your nook.</Text>
    <View style={s.authPanel}>
      <Text style={s.authPanelTitle}>Create your account</Text>
      <View style={s.authTabs}>
        <Pressable onPress={() => { setAuthType('email'); setAuthValue(''); setAuthError(''); }} style={[s.authTab, authType === 'email' && s.authTabActive]}><Icon name="mail-outline" size={18} color={authType === 'email' ? C.deep : C.white} /><Text style={[s.authTabText, authType === 'email' && s.authTabTextActive]}>Email</Text></Pressable>
        <Pressable onPress={() => { setAuthType('phone'); setAuthValue(''); setAuthError(''); }} style={[s.authTab, authType === 'phone' && s.authTabActive]}><Icon name="call-outline" size={18} color={authType === 'phone' ? C.deep : C.white} /><Text style={[s.authTabText, authType === 'phone' && s.authTabTextActive]}>Phone</Text></Pressable>
      </View>
      {(authType === 'email' || authType === 'phone') && <><Text style={s.inputLabel}>{authType === 'email' ? 'Email address' : 'Phone number'}</Text><TextInput value={authValue} onChangeText={setAuthValue} autoCapitalize="none" keyboardType={authType === 'email' ? 'email-address' : 'phone-pad'} autoComplete={authType === 'email' ? 'email' : 'tel'} placeholder={authType === 'email' ? 'you@example.com' : '+1 555 123 4567'} placeholderTextColor={C.muted} style={s.input} /></>}
      {(authType === 'google' || authType === 'microsoft') && <Text style={s.authProviderNote}>{authType === 'google' ? 'Google' : 'Microsoft'} sign-in is selected. This preview will continue to the questionnaire without connecting an account.</Text>}
      {authError ? <Text style={s.error}>{authError}</Text> : null}
      <Pressable onPress={continueAuth}><LinearGradient colors={['#F66769', '#FFB86B']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={s.authContinue}><Text style={s.authContinueText}>Continue</Text><Icon name="arrow-forward" size={20} color={C.deep} /></LinearGradient></Pressable>
      <Text style={s.authDivider}>OR CONTINUE WITH</Text>
      <View style={s.authSocialRow}>
        <Pressable onPress={() => { setAuthType('google'); setAuthError(''); }} style={[s.authSocial, authType === 'google' && s.authSocialSelected]}><Text style={s.authSocialLetter}>G</Text><Text style={s.authSocialText}>Google</Text></Pressable>
        <Pressable onPress={() => { setAuthType('microsoft'); setAuthError(''); }} style={[s.authSocial, authType === 'microsoft' && s.authSocialSelected]}><Text style={s.authMicrosoftMark}>▦</Text><Text style={s.authSocialText}>Microsoft</Text></Pressable>
      </View>
    </View>
    <Text style={s.authDisclosure}>Prototype preview: no account is created, and no email or SMS is sent. Google and Microsoft sign-in are not connected yet.</Text>
  </View>;

  const home = <>
    <View style={{ marginTop: 14, marginBottom: 20 }}><Eyebrow>WELCOME TO YOUR NOOK</Eyebrow><Text style={s.heroTitle}>Hello, {answers.city.trim()}.</Text><Text style={s.heroSub}>Your move starts here. What would you like to do first?</Text></View>
    <LinearGradient colors={['#1C356F', '#182F63']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.heroCard}>
      <View style={s.heroTop}><View style={s.heroBubble}><Icon name="compass-outline" size={24} color={C.green} /></View><Text style={s.heroSmall}>YOUR NEIGHBOURHOOD MATCH</Text></View>
      <Text style={s.heroCardTitle}>Find a place that fits your life.</Text>
      <Text style={s.heroCardBody}>Compare your rent, commute and everyday costs near {answers.university}.</Text>
      <Pressable onPress={() => go('results')} style={s.heroButton}><Text style={s.heroButtonText}>Explore neighbourhoods</Text><Icon name="arrow-forward" size={19} color={C.deep} /></Pressable>
      <View style={s.heroDecorOne} /><View style={s.heroDecorTwo} />
    </LinearGradient>
    <View style={{ height: 28 }} /><SectionTitle title="Choose what you need" />
    <View style={s.homeActionList}>{[
      { icon: 'key-outline' as const, title: 'Move', sub: 'Arrange a viewing and compare flats', action: () => go('move') },
      { icon: 'bed-outline' as const, title: 'First night', sub: 'Plan the essentials for move-in', action: () => go('kit') },
      { icon: 'checkbox-outline' as const, title: 'Settle', sub: 'Keep track of your arrival tasks', action: () => go('settle') },
      { icon: 'people-outline' as const, title: 'Circle', sub: 'Find familiar faces in your new city', action: () => go('circle') },
    ].map(item => <Pressable key={item.title} onPress={item.action} style={s.homeAction}><View style={s.homeActionIcon}><Icon name={item.icon} size={22} color={C.green} /></View><View style={{ flex: 1 }}><Text style={s.homeActionTitle}>{item.title}</Text><Text style={s.homeActionSub}>{item.sub}</Text></View><Icon name="arrow-forward" size={19} color={C.orange} /></Pressable>)}</View>
    <View style={{ height: 26 }} /><SectionTitle title="Your plan" action="Edit answers" onAction={startQuiz} />
    <Card><Row icon="airplane-outline" title={`${answers.originCountry} → ${answers.city}`} subtitle={`${answers.country} · ${answers.university}`} /><View style={s.divider} /><Row icon="home-outline" title={answers.homeType === 'solo' ? 'Living alone' : 'Sharing with flatmates'} subtitle={`Rent budget: ${money(answers.budget, answers.currency)} / month${budgetInput ? ` · from ${money(Number(budgetInput), answers.preferredCurrency)}` : ''}`} /><View style={s.divider} /><Row icon="cash-outline" title={`Familiar currency: ${answers.preferredCurrency}`} subtitle={answers.preferredCurrency === answers.currency ? 'Same as the rent currency' : rateStatus === 'ready' ? `Automatic rate · ${rateDate}` : rateStatus === 'loading' ? 'Updating exchange rate' : 'Rate unavailable; prices stay in rent currency'} /></Card>
    <Text style={s.demoNote}>Prototype preview · London, UK contains sample area data. For other cities, add areas and compare your own figures.</Text>
  </>;

  const quiz = <>
    <View style={s.backRow}><Pressable onPress={() => quizStep === 0 ? go('auth') : setQuizStep(quizStep - 1)} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable><Text style={s.progressText}>{quizStep + 1} OF {quizSteps.length}</Text></View>
    <View style={s.progressTrack}><View style={[s.progressFill, { width: `${((quizStep + 1) / quizSteps.length) * 100}%` }]} /></View>
    <View style={{ marginTop: 30, marginBottom: 26 }}><Eyebrow>FIND YOUR NOOK</Eyebrow><Text style={s.pageTitle}>{quizSteps[quizStep].title}</Text><Text style={s.pageSub}>{quizSteps[quizStep].subtitle}</Text></View>
    {quizStep === 0 && <View>
      <Text style={s.inputLabel}>Search country *</Text><TextInput value={answers.country} onChangeText={value => setAnswers(prev => ({ ...prev, country: value, city: '', university: '', currency: currencyFor(value) }))} placeholder="Start typing a country" placeholderTextColor={C.muted} style={s.input} />
      <View style={s.choiceList}>{places.filter(item => !answers.country || item.country.toLowerCase().includes(answers.country.toLowerCase())).slice(0, 8).map(item => <Choice key={item.country} label={item.country} selected={answers.country === item.country} onPress={() => setAnswers(prev => ({ ...prev, country: item.country, city: '', university: '', currency: item.currency }))} icon="globe-outline" />)}</View>
      <Text style={s.quizHint}>Any country is welcome. If yours is not shown, type its name above.</Text>
    </View>}
    {quizStep === 1 && <View><Text style={s.inputLabel}>Search city *</Text><TextInput value={answers.city} onChangeText={value => setAnswers(prev => ({ ...prev, city: value, university: '', destination: 'other' }))} placeholder="e.g. London, Tokyo, Tashkent" placeholderTextColor={C.muted} style={s.input} /><View style={s.choiceList}>{citiesFor(answers.country).filter(item => !answers.city || item.city.toLowerCase().includes(answers.city.toLowerCase())).map(item => <Choice key={item.city} label={item.city} selected={answers.city === item.city} onPress={() => setAnswers(prev => ({ ...prev, city: item.city, university: '', destination: 'other' }))} icon="location-outline" />)}</View><Text style={s.quizHint}>Going somewhere else? Type any city above.</Text></View>}
    {quizStep === 2 && <View><Text style={s.inputLabel}>University *</Text><TextInput value={answers.university} onChangeText={value => setAnswers(prev => ({ ...prev, university: value, customDestination: value, destination: 'other' }))} placeholder="Search or enter your university" placeholderTextColor={C.muted} style={s.input} /><View style={s.choiceList}>{universitiesFor(answers.country, answers.city).filter(name => !answers.university || name.toLowerCase().includes(answers.university.toLowerCase())).map(name => <Choice key={name} label={name} selected={answers.university === name} onPress={() => setAnswers(prev => ({ ...prev, university: name, customDestination: name, destination: name === 'Imperial College London' ? 'imperial' : name.includes('UCL') ? 'ucl' : name.includes('King’s College') ? 'kings' : name.includes('LSE') ? 'lse' : 'other' }))} icon="school-outline" />)}</View><Text style={s.quizHint}>If your university is not listed, type its full name above.</Text></View>}
    {quizStep === 3 && <View><Text style={s.inputLabel}>Your home country *</Text><TextInput value={answers.originCountry} onChangeText={value => setAnswers(prev => ({ ...prev, originCountry: value, preferredCurrency: currencyFor(value), exchangeRate: currencyFor(value) === prev.currency ? 1 : 0 }))} placeholder="Start typing your home country" placeholderTextColor={C.muted} style={s.input} /><View style={s.choiceList}>{places.filter(item => !answers.originCountry || item.country.toLowerCase().includes(answers.originCountry.toLowerCase())).slice(0, 8).map(item => <Choice key={item.country} label={item.country} selected={answers.originCountry === item.country} onPress={() => { setAnswers(prev => ({ ...prev, originCountry: item.country, preferredCurrency: item.currency, exchangeRate: item.currency === prev.currency ? 1 : 0 })); }} icon="airplane-outline" />)}</View><Text style={s.quizHint}>Your country is not listed? Type its name above.</Text></View>}
    {quizStep === 4 && <View>
      <Text style={s.inputLabel}>Currency used for rent in {answers.city} *</Text>
      <TextInput value={answers.currency} onChangeText={value => { const code = value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3); setAnswers(prev => ({ ...prev, currency: code, exchangeRate: 0 })); }} autoCapitalize="characters" maxLength={3} placeholder="e.g. GBP, USD, EUR" placeholderTextColor={C.muted} style={s.input} />
      <Text style={s.inputLabel}>Choose your familiar currency *</Text>
      <TextInput value={answers.preferredCurrency} onChangeText={value => setFamiliarCurrency(value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3))} autoCapitalize="characters" maxLength={3} placeholder="e.g. USD, EUR, UZS" placeholderTextColor={C.muted} style={s.input} />
      <View style={s.currencyGrid}>{commonCurrencies.map(code => <Pressable key={code} onPress={() => setFamiliarCurrency(code)} style={[s.currencyChip, answers.preferredCurrency === code && s.currencyChipSelected]}><Text style={[s.currencyChipText, answers.preferredCurrency === code && s.currencyChipTextSelected]}>{code}</Text></Pressable>)}</View>
      <Text style={s.quizHint}>Enter your budget in your familiar currency on the next screen. We’ll convert it to {answers.currency || 'the destination currency'} for local comparisons.</Text>
      {answers.currency.length === 3 && answers.preferredCurrency.length === 3 && answers.currency !== answers.preferredCurrency && <View style={s.rateCard}>
        <Text style={s.rateTitle}>{rateStatus === 'loading' ? 'Finding the latest rate…' : rateStatus === 'ready' ? `1 ${answers.currency} ≈ ${answers.exchangeRate.toLocaleString('en-GB', { maximumFractionDigits: 4 })} ${answers.preferredCurrency}` : 'Rate unavailable right now'}</Text>
        <Text style={s.rateNote}>{rateStatus === 'ready' ? `Rate dated ${rateDate} · Frankfurter reference data. Your bank’s rate may differ.` : rateStatus === 'error' ? 'We’ll keep prices in the rent currency until the service responds.' : 'Checking the latest available reference rate.'}</Text>
        {rateStatus === 'error' && <Pressable onPress={() => setRateRetry(value => value + 1)}><Text style={s.link}>Try again</Text></Pressable>}
      </View>}
    </View>}
    {quizStep === 5 && <View style={s.choiceList}>{([['solo', 'Live alone', 'Compare whole-apartment rents'], ['shared', 'Share with flatmates', 'Compare room rents']] as const).map(([value, label, detail]) => <Choice key={value} label={label} detail={detail} selected={answers.homeType === value} onPress={() => updateAnswer('homeType', value as HomeType)} icon="home-outline" />)}</View>}
    {quizStep === 6 && <View>
      <Text style={s.inputLabel}>Your currency *</Text>
      <TextInput value={answers.preferredCurrency} onChangeText={value => setFamiliarCurrency(value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3))} autoCapitalize="characters" maxLength={3} placeholder="e.g. USD, EUR, UZS" placeholderTextColor={C.muted} style={s.input} />
      <View style={[s.currencyGrid, { marginBottom: 18 }]}>{commonCurrencies.map(code => <Pressable key={code} onPress={() => setFamiliarCurrency(code)} style={[s.currencyChip, answers.preferredCurrency === code && s.currencyChipSelected]}><Text style={[s.currencyChipText, answers.preferredCurrency === code && s.currencyChipTextSelected]}>{code}</Text></Pressable>)}</View>
      <Text style={s.inputLabel}>Monthly rent budget ({answers.preferredCurrency || 'your currency'}) *</Text>
      <TextInput value={budgetInput} onChangeText={value => setBudgetInput(value.replace(/[^0-9]/g, ''))} keyboardType="numeric" placeholder={`Enter an amount in ${answers.preferredCurrency || 'your currency'}`} placeholderTextColor={C.muted} style={s.input} />
      <View style={s.rateCard}><Text style={s.rateTitle}>{convertedBudget > 0 ? `${money(Number(budgetInput), answers.preferredCurrency)} ≈ ${money(convertedBudget, answers.currency)}` : rateStatus === 'loading' ? 'Converting your budget…' : 'Your budget in the destination currency'}</Text>
        <Text style={s.rateNote}>{answers.currency === answers.preferredCurrency ? `Both amounts are in ${answers.currency}.` : rateStatus === 'ready' ? `Using the reference rate dated ${rateDate}. Your bank’s rate may differ.` : rateStatus === 'error' ? 'The rate is unavailable. Try again to convert your budget.' : 'Enter an amount to see the conversion.'}</Text>
        {rateStatus === 'error' && <Pressable onPress={() => setRateRetry(value => value + 1)}><Text style={s.link}>Try again</Text></Pressable>}
      </View>
    </View>}
    {quizStep === 7 && <View style={s.choiceList}>{[2, 3, 4, 5].map(value => <Choice key={value} label={`${value} days a week`} selected={answers.daysPerWeek === value} onPress={() => updateAnswer('daysPerWeek', value)} icon="train-outline" />)}</View>}
    {quizStep === 8 && <View style={s.choiceList}>{([['halal', 'Halal food nearby'], ['international', 'International groceries'], ['none', 'No strong preference']] as const).map(([value, label]) => <Choice key={value} label={label} selected={answers.food === value} onPress={() => updateAnswer('food', value as FoodPreference)} icon="basket-outline" />)}</View>}
    {quizStep === 9 && <View style={s.choiceList}>{([['parks', 'Parks & fresh air'], ['fitness', 'Sport & movement'], ['nightlife', 'A lively evening scene'], ['quiet', 'Peace & quiet']] as const).map(([value, label]) => <Choice key={value} label={label} selected={answers.lifestyle === value} onPress={() => updateAnswer('lifestyle', value as Lifestyle)} icon="heart-outline" />)}</View>}
    <View style={{ height: 28 }} /><Button title={quizStep === quizSteps.length - 1 ? 'Go to my Nooks home' : 'Continue'} disabled={(quizStep === 0 && !answers.country.trim()) || (quizStep === 1 && !answers.city.trim()) || (quizStep === 2 && !answers.university.trim()) || (quizStep === 3 && !answers.originCountry.trim()) || (quizStep === 4 && (answers.currency.length !== 3 || answers.preferredCurrency.length !== 3)) || (quizStep === 6 && (convertedBudget <= 0 || answers.currency.length !== 3 || answers.preferredCurrency.length !== 3))} onPress={() => quizStep === quizSteps.length - 1 ? go('home') : setQuizStep(quizStep + 1)} icon="arrow-forward" />
    <Text style={s.quizFoot}>Your answers stay on this device in this demo session.</Text>
  </>;

  const results = <>
    <View style={s.backRow}><Pressable onPress={() => go('home')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable><Pressable onPress={startQuiz}><Text style={s.link}>Edit answers</Text></Pressable></View>
    <Eyebrow>{answers.city.trim().toUpperCase()} · YOUR MATCHES</Eyebrow><Text style={s.pageTitle}>A place that fits your life.</Text><Text style={s.pageSub}>{ranked.length ? 'Ranked for your rent budget, commute and preferences.' : 'Build a comparison with local figures for your destination city.'}</Text>
    <Text style={s.quizHint}>From {answers.originCountry} · {answers.homeType === 'solo' ? 'Living alone' : 'Sharing'} · Prices in {answers.currency}{answers.preferredCurrency !== answers.currency ? ` · Familiar currency ${answers.preferredCurrency}${rateStatus === 'ready' ? ` at ${rateDate} reference rate` : ' when a rate is available'}` : ''}</Text>
    <View style={{ height: 22 }} />
    {ranked.length === 0 && <Card style={{ marginBottom: 14, backgroundColor: C.soft }}><View style={s.emptyIcon}><Icon name="globe-outline" size={28} color={C.green} /></View><Text style={s.featureTitle}>Start with {answers.city.trim()}</Text><Text style={s.featureBody}>Automatic rental and transport data is not connected for this city yet. Add neighbourhoods you are considering and compare their full monthly costs without made-up figures.</Text><Button title="Add a neighbourhood" onPress={() => go('addArea')} small icon="add" /></Card>}
    {ranked.slice(0, 3).map((item, index) => <Pressable key={item.area.id} onPress={() => selectArea(item.area.id)} style={s.areaCard}>
      <View style={[s.areaArt, { backgroundColor: item.area.accent }]}><View style={s.areaArtCircle}><Icon name={item.area.icon as keyof typeof Ionicons.glyphMap} size={34} color={C.green} /></View><Text style={s.areaArtZone}>{item.area.zone}</Text></View>
      <View style={{ padding: 17 }}><View style={s.costRow}><Text style={s.matchBadge}>{index === 0 ? 'BEST MATCH' : `MATCH 0${index + 1}`}</Text><Icon name="arrow-forward" size={18} color={C.green} /></View><Text style={s.areaName}>{item.area.name}</Text><Text style={s.muted}>{item.area.character}</Text>
        <View style={s.areaFacts}><Text style={s.factText}>◷  {item.commute === null ? 'Commute to confirm' : `${item.commute} min commute`}</Text><Text style={s.factText}>⌂  {money(item.cost.total, answers.currency)}/mo total</Text>{answers.preferredCurrency !== answers.currency && answers.exchangeRate > 0 && <Text style={s.factText}>≈ {money(item.cost.total * answers.exchangeRate, answers.preferredCurrency)} in your currency</Text>}</View>
      </View>
    </Pressable>)}
    {ranked.length > 0 && <Button title="Compare these areas" onPress={() => go('compare')} secondary icon="git-compare-outline" />}
    <View style={{ height: 10 }} /><Button title="Add an area with my figures" onPress={() => go('addArea')} secondary small icon="add" />
    <Text style={s.demoNote}>London uses illustrative sample figures. Other areas use numbers you enter. Confirm all costs and routes before committing to a home.</Text>
  </>;

  const addArea = <>
    <View style={s.backRow}><Pressable onPress={() => go('results')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable></View>
    <Eyebrow>{answers.city.trim().toUpperCase()} · YOUR AREA</Eyebrow><Text style={s.pageTitle}>Add a neighbourhood.</Text><Text style={s.pageSub}>Use figures from listings and local transport sources to compare anywhere in the world.</Text>
    <View style={{ height: 22 }} />
    {([
      ['Area name *', newAreaName, setNewAreaName, 'e.g. Shibuya', false],
      [`Monthly rent (${answers.currency}) *`, newAreaRent, setNewAreaRent, 'e.g. 1200', true],
      [`Monthly bills (${answers.currency}) *`, newAreaBills, setNewAreaBills, 'e.g. 150', true],
      [`One-way fare (${answers.currency}) *`, newAreaFare, setNewAreaFare, 'e.g. 3', true],
      ['One-way commute (minutes) *', newAreaCommute, setNewAreaCommute, 'e.g. 35', true],
      [`Local taxes per month (${answers.currency})`, newAreaTax, setNewAreaTax, '0 if none or exempt', true],
    ] as const).map(([label, value, setter, placeholder, numeric]) => <View key={label}><Text style={s.inputLabel}>{label}</Text><TextInput value={value} onChangeText={setter} keyboardType={numeric ? 'decimal-pad' : 'default'} placeholder={placeholder} placeholderTextColor={C.muted} style={s.input} /></View>)}
    {areaError ? <Text style={s.error}>{areaError}</Text> : null}
    <Button title="Add to comparison" onPress={saveArea} icon="arrow-forward" />
    <Text style={s.demoNote}>Your entries are kept only during this demo session. Nooks does not verify these figures.</Text>
  </>;

  const area = <>
    <View style={s.backRow}><Pressable onPress={() => go('results')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable><Text style={s.progressText}>{selectedArea.zone.toUpperCase()}</Text></View>
    <View style={[s.areaHero, { backgroundColor: selectedArea.accent }]}><View style={s.areaHeroCircle}><Icon name={selectedArea.icon as keyof typeof Ionicons.glyphMap} size={60} color={C.green} /></View><Text style={s.areaHeroLabel}>A NOOK TO EXPLORE</Text></View>
    <View style={{ height: 22 }} /><Eyebrow>NEIGHBOURHOOD MATCH</Eyebrow><Text style={s.pageTitle}>{selectedArea.name}</Text><Text style={s.pageSub}>{selectedArea.character}</Text>
    <View style={{ height: 22 }} /><Card><SectionTitle title="Monthly picture" /><CostRows area={selectedArea} answers={answers} /></Card>
    <View style={{ height: 14 }} /><Card><Row icon="train-outline" title="To your destination" trailing={getCommute(selectedArea, answers) === null ? 'Check route' : `~${getCommute(selectedArea, answers)} min`} /><View style={s.divider} /><Row icon="basket-outline" title="Everyday essentials" subtitle="Check individual shops before choosing a home" /></Card>
    <Text style={s.demoNote}>London figures are illustrative. Other area figures are entered by you. Bills and local taxes vary by property and eligibility. Deposits and setup costs are additional.</Text>
    <Button title="Book a viewing here" onPress={() => go('booking')} icon="arrow-forward" />
  </>;

  const compare = <>
    <View style={s.backRow}><Pressable onPress={() => go('results')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable></View>
    <Eyebrow>{answers.city.trim().toUpperCase()} · SIDE BY SIDE</Eyebrow><Text style={s.pageTitle}>See the whole picture.</Text><Text style={s.pageSub}>Compare recurring monthly costs and the time you spend travelling.</Text>
    <View style={{ height: 23 }} />
    {ranked.slice(0, 3).map(item => <Card key={item.area.id} style={{ marginBottom: 12 }}><View style={s.costRow}><Text style={s.compareName}>{item.area.name}</Text><Text style={s.compareZone}>{item.area.zone}</Text></View><View style={s.divider} /><CostRows area={item.area} answers={answers} /><View style={{ height: 13 }} /><Text style={s.factText}>{item.commute === null ? 'Commute: check your route' : `About ${item.commute} min each way`}</Text><View style={{ height: 15 }} /><Button title={`Explore ${item.area.name}`} onPress={() => selectArea(item.area.id)} small secondary icon="arrow-forward" /></Card>)}
    <Text style={s.demoNote}>London uses illustrative demo data. Other values come from your entries. Upfront costs are not included.</Text>
  </>;

  const booking = <>
    <View style={s.backRow}><Pressable onPress={() => go('area')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable></View>
    <Eyebrow>NOOKS MOVE</Eyebrow><Text style={s.pageTitle}>See it before you sign.</Text><Text style={s.pageSub}>A local rep can visit the flat and send a structured report.</Text>
    <View style={{ height: 23 }} /><Card><Row icon="location-outline" title={`${selectedArea.name}, ${answers.city.trim()}`} subtitle="Your selected neighbourhood" /></Card>
    <View style={{ height: 21 }} /><Text style={s.inputLabel}>Listing address or link *</Text><TextInput value={address} onChangeText={setAddress} style={s.input} placeholder="Paste an address or listing URL" placeholderTextColor={C.muted} autoCapitalize="none" />
    <Text style={s.inputLabel}>Viewing time window *</Text><TextInput value={time} onChangeText={setTime} style={s.input} placeholder="e.g. Tuesday 2–4 pm" placeholderTextColor={C.muted} />
    <Text style={s.inputLabel}>Questions for the rep</Text><TextInput value={questions} onChangeText={setQuestions} style={[s.input, { height: 106, textAlignVertical: 'top', paddingTop: 16 }]} multiline placeholder="What should they look for?" placeholderTextColor={C.muted} />
    {bookingError ? <Text style={s.error}>{bookingError}</Text> : null}
    <Card style={{ marginTop: 8, marginBottom: 18, backgroundColor: C.soft }}><View style={s.costRow}><Text style={s.compareName}>Single viewing</Text><Text style={s.factText}>Price to confirm</Text></View><Text style={[s.muted, { marginTop: 6 }]}>Pricing depends on the city. This demo creates a local request and does not take payment or notify a real rep.</Text></Card>
    <Button title="Create demo request" onPress={submitBooking} icon="arrow-forward" />
  </>;

  const move = <>
    <Eyebrow>NOOKS MOVE</Eyebrow><Text style={s.pageTitle}>Your move, in motion.</Text><Text style={s.pageSub}>A clear view of every place you are considering.</Text>
    <View style={{ height: 25 }} /><SectionTitle title="Viewings" action="New request" onAction={() => ranked.length ? selectArea(ranked[0].area.id, 'booking') : go('results')} />
    {bookings.length === 0 && <Card style={{ marginBottom: 16 }}><View style={s.emptyIcon}><Icon name="home-outline" size={28} color={C.green} /></View><Text style={s.featureTitle}>No viewings yet</Text><Text style={s.featureBody}>Start with your neighbourhood comparison, then book a local rep to see a listing.</Text><Button title="Find my area" onPress={startQuiz} small icon="arrow-forward" /></Card>}
    {bookings.map(item => <Card key={item.id} style={{ marginBottom: 12 }}><View style={s.costRow}><Text style={s.matchBadge}>{item.status === 'complete' ? 'REPORT READY' : item.status === 'accepted' ? 'REP ASSIGNED' : 'AWAITING REP'}</Text><Icon name="home-outline" size={20} color={C.green} /></View><Text style={[s.compareName, { marginTop: 13 }]}>{item.address}</Text><Text style={[s.muted, { marginTop: 5 }]}>{item.time} · {allAreas.find(area => area.id === item.areaId)?.name}</Text>{item.rep && <Text style={[s.factText, { marginTop: 11 }]}>Rep: {item.rep}</Text>}{item.report && <><View style={s.divider} /><Text style={s.inputLabel}>Viewing report</Text><Text style={s.reportBody}>{item.report}</Text>{item.notes && <Text style={[s.muted, { marginTop: 8 }]}>Notes: {item.notes}</Text>}</>}</Card>)}
    <View style={{ height: 12 }} /><SectionTitle title="Next steps" /><Card><Row icon="bed-outline" title="Prepare your first night" subtitle="Build a kit for your actual flat" onPress={() => go('kit')} /><View style={s.divider} /><Row icon="checkbox-outline" title="Settle checklist" subtitle="Keep important tasks together" onPress={() => go('settle')} /></Card>
    <Text style={s.demoNote}>Live video, photo uploads, payments and rep identity checks need backend integrations before real orders.</Text>
  </>;

  const settle = <>
    <Eyebrow>NOOKS SETTLE</Eyebrow><Text style={s.pageTitle}>One thing at a time.</Text><Text style={s.pageSub}>A simple guide to your first weeks in {answers.city.trim() || 'a new city'}.</Text>
    <View style={{ height: 20 }} /><Card style={{ backgroundColor: C.lime, borderColor: C.lime }}><View style={s.costRow}><View><Text style={s.compareName}>Your progress</Text><Text style={s.muted}>{completedTasks} of {activeSettleTasks.length} essentials checked</Text></View><Text style={s.progressNumber}>{Math.round(completedTasks / activeSettleTasks.length * 100)}%</Text></View><View style={[s.progressTrack, { marginTop: 15, backgroundColor: '#BED5B4' }]}><View style={[s.progressFill, { width: `${completedTasks / activeSettleTasks.length * 100}%` }]} /></View></Card>
    <View style={{ height: 26 }} /><SectionTitle title="Your checklist" />
    {activeSettleTasks.map(item => <Pressable key={item.id} onPress={() => setDoneTasks(prev => prev.includes(item.id) ? prev.filter(id => id !== item.id) : [...prev, item.id])} style={s.taskRow}><View style={s.taskIcon}><Icon name={item.icon} size={22} color={C.green} /></View><View style={{ flex: 1 }}><Text style={[s.taskTitle, doneTasks.includes(item.id) && { textDecorationLine: 'line-through', color: C.muted }]}>{item.title}</Text><Text style={s.taskSub}>{item.subtitle}</Text></View><Icon name={doneTasks.includes(item.id) ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={doneTasks.includes(item.id) ? C.green : '#AEBDB1'} /></Pressable>)}
    <Card style={{ marginTop: 16, backgroundColor: C.soft }}><Row icon="information-circle-outline" title="Need specialist help?" subtitle="Use a qualified adviser for immigration or tax questions." /></Card>
    <Text style={s.demoNote}>{answers.city.trim().toLowerCase() === 'london' ? 'UK sample checklist.' : 'General starter checklist.'} Requirements vary by country. Confirm them with official services or a qualified adviser.</Text>
  </>;

  const kit = <>
    <View style={s.backRow}><Pressable onPress={() => go('move')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable></View>
    <Eyebrow>MOVE-IN ESSENTIALS</Eyebrow><Text style={s.pageTitle}>Your first night, sorted.</Text><Text style={s.pageSub}>Choose a shopping list. A rep buys items only after you confirm the exact order.</Text>
    <View style={{ height: 22 }} />
    {(['Basic', 'Comfort'] as const).map(name => <Pressable key={name} onPress={() => { setKitSelection(name); setKitRequested(false); }} style={[s.kitCard, kitSelection === name && { borderColor: C.green, borderWidth: 2 }]}><View style={s.costRow}><View style={[s.kitIcon, { backgroundColor: name === 'Basic' ? C.lime : C.purple }]}><Icon name={name === 'Basic' ? 'bed-outline' : 'sparkles-outline'} size={24} color={C.green} /></View><Icon name={kitSelection === name ? 'checkmark-circle' : 'ellipse-outline'} size={25} color={kitSelection === name ? C.green : '#AEBDB1'} /></View><Text style={s.compareName}>{name} kit</Text><Text style={[s.muted, { marginTop: 5 }]}>{(name === 'Basic' ? basicItems : comfortItems).join(' · ')}</Text><Text style={[s.factText, { marginTop: 12 }]}>Items at actual cost · service fee confirmed locally</Text></Pressable>)}
    <Card style={{ backgroundColor: C.soft, marginBottom: 18 }}><Row icon="key-outline" title="Access to your flat" subtitle="Delivery before arrival requires permission and keys. Otherwise, arrange arrival-day delivery." /></Card>
    <Button title={kitRequested ? 'Added to your plan' : `Add ${kitSelection} to my plan`} onPress={() => setKitRequested(true)} disabled={kitRequested} icon={kitRequested ? 'checkmark' : 'arrow-forward'} />
    <Text style={s.demoNote}>This is a local demo request. No items are bought and no payment is taken.</Text>
  </>;

  const circle = <>
    <Eyebrow>NOOKS CIRCLE</Eyebrow><Text style={s.pageTitle}>Stay close to the people you meet.</Text><Text style={s.pageSub}>A regular small group and a familiar face can make a new city feel smaller.</Text>
    <View style={{ height: 24 }} /><LinearGradient colors={['#DDE9DB', '#E9E5F5']} style={s.circleArt}><View style={s.circlePerson}><Icon name="person" size={40} color={C.green} /></View><View style={[s.circlePerson, { marginLeft: -15, marginTop: 35, backgroundColor: '#FAE8D7' }]}><Icon name="person" size={40} color={C.green} /></View><View style={[s.circlePerson, { marginLeft: -15, marginTop: 8, backgroundColor: '#FFF' }]}><Icon name="person" size={40} color={C.green} /></View></LinearGradient>
    <View style={{ height: 20 }} /><Card><Row icon="calendar-outline" title="A regular time" subtitle="The same slot makes showing up easier." /><View style={s.divider} /><Row icon="people-outline" title="A small familiar group" subtitle="Connections grow through meeting again." /><View style={s.divider} /><Row icon="heart-outline" title="Built around real life" subtitle="Start with people you already met through Nooks." /></Card>
    <Text style={s.demoNote}>Circle is a concept preview. Group matching and subscriptions are not active in this prototype.</Text>
  </>;

  const rep = <>
    <Eyebrow>REP WORKSPACE · DEMO</Eyebrow><Text style={s.pageTitle}>Good work starts local.</Text><Text style={s.pageSub}>See nearby requests, complete a clear report and help someone make a confident move.</Text>
    <View style={{ height: 20 }} /><Card style={{ backgroundColor: C.lime, borderColor: C.lime }}><Row icon="shield-checkmark-outline" title="Verification required to go live" subtitle="ID check and short training before real assignments" /></Card>
    <View style={{ height: 23 }} /><SectionTitle title="Available requests" />
    {bookings.filter(item => item.status === 'open').map(item => <Card key={item.id} style={{ marginBottom: 12 }}><Text style={s.matchBadge}>NEW REQUEST</Text><Text style={[s.compareName, { marginTop: 11 }]}>{item.address}</Text><Text style={[s.muted, { marginTop: 5 }]}>{item.time} · {allAreas.find(area => area.id === item.areaId)?.name}</Text>{item.questions && <Text style={[s.reportBody, { marginTop: 12 }]}>“{item.questions}”</Text>}<View style={{ height: 14 }} /><Button title="Accept demo request" onPress={() => acceptBooking(item.id)} small icon="checkmark" /></Card>)}
    {bookings.filter(item => item.status === 'open').length === 0 && <Card><Text style={s.muted}>No open requests right now.</Text></Card>}
    <View style={{ height: 20 }} /><SectionTitle title="My assignments" />
    {bookings.filter(item => item.status !== 'open').map(item => <Card key={item.id} style={{ marginBottom: 12 }}><Text style={s.matchBadge}>{item.status === 'complete' ? 'REPORT SENT' : 'ACCEPTED'}</Text><Text style={[s.compareName, { marginTop: 10 }]}>{item.address}</Text><Text style={[s.muted, { marginTop: 5 }]}>{item.time}</Text>{item.status === 'accepted' && <><View style={{ height: 14 }} /><Button title="Complete report" onPress={() => { setReportBookingId(item.id); go('report'); }} small secondary icon="document-text-outline" /></>}</Card>)}
    {bookings.filter(item => item.status !== 'open').length === 0 && <Card><Text style={s.muted}>Accepted requests will appear here.</Text></Card>}
    <Text style={s.demoNote}>Requests are stored only in this running demo. Payouts, identity checks, live calls and push notifications are not connected.</Text>
  </>;

  const report = <>
    <View style={s.backRow}><Pressable onPress={() => go('rep')} style={s.backButton}><Icon name="arrow-back" size={22} /></Pressable></View>
    <Eyebrow>REP REPORT</Eyebrow><Text style={s.pageTitle}>Help them see clearly.</Text><Text style={s.pageSub}>{activeBooking?.address ?? 'Viewing'}</Text>
    <View style={{ height: 21 }} /><Card><Row icon="water-outline" title="Damp" subtitle="Check corners, walls and behind furniture" /><View style={s.divider} /><Row icon="volume-medium-outline" title="Noise" subtitle="Listen with windows open and closed" /><View style={s.divider} /><Row icon="sunny-outline" title="Natural light" subtitle="Describe the room at the viewing time" /><View style={s.divider} /><Row icon="construct-outline" title="Condition" subtitle="Note wear, appliances and missing items" /></Card>
    <View style={{ height: 20 }} /><Text style={s.inputLabel}>Overall findings *</Text><TextInput value={reportText} onChangeText={setReportText} style={[s.input, { height: 145, textAlignVertical: 'top', paddingTop: 16 }]} multiline placeholder="What did you see? Include damp, noise, light and condition." placeholderTextColor={C.muted} />
    <Text style={s.inputLabel}>Questions answered / follow-up</Text><TextInput value={reportNotes} onChangeText={setReportNotes} style={[s.input, { height: 98, textAlignVertical: 'top', paddingTop: 16 }]} multiline placeholder="Any answers from the agent or landlord?" placeholderTextColor={C.muted} />
    <Button title="Send demo report" onPress={saveReport} disabled={!reportText.trim()} icon="send-outline" />
    <Text style={s.demoNote}>Photo and voice-note uploads will need secure storage in a connected version.</Text>
  </>;

  const content: Record<Screen, React.ReactNode> = { auth, home, quiz, results, area, compare, addArea, booking, move, settle, kit, circle, rep, report };
  const showNav = ['home', 'move', 'settle', 'circle', 'rep'].includes(screen);
  return <SafeAreaView style={s.safe} edges={['top', 'bottom']}><StatusBar style="light" />{screen !== 'auth' && header}<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}><ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" contentContainerStyle={s.scrollContent}>{content[screen]}</ScrollView></KeyboardAvoidingView>
    {showNav && <View style={s.nav}>{(showRep ? [
      { key: 'rep' as Screen, label: 'Requests', icon: 'list-outline' as const },
      { key: 'home' as Screen, label: 'Client', icon: 'person-outline' as const },
    ] : [
      { key: 'home' as Screen, label: 'Discover', icon: 'compass-outline' as const },
      { key: 'move' as Screen, label: 'Move', icon: 'key-outline' as const },
      { key: 'settle' as Screen, label: 'Settle', icon: 'checkbox-outline' as const },
      { key: 'circle' as Screen, label: 'Circle', icon: 'people-outline' as const },
    ]).map(item => <Pressable key={item.key} onPress={() => { if (item.key === 'home') setShowRep(false); go(item.key); }} style={s.navItem}><Icon name={item.icon} size={22} color={screen === item.key ? C.green : '#8B9B90'} /><Text style={[s.navText, screen === item.key && { color: C.green, fontWeight: '800' }]}>{item.label}</Text></Pressable>)}</View>}
  </SafeAreaView>;
}

export default function App() { return <SafeAreaProvider><AppContent /></SafeAreaProvider>; }

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg }, scrollContent: { paddingHorizontal: 22, paddingBottom: 34, width: '100%', maxWidth: 480, alignSelf: 'center' },
  authWrap: { paddingTop: 32, paddingBottom: 28, overflow: 'hidden' }, authHalo: { position: 'absolute', width: 280, height: 280, borderRadius: 140, right: -190, top: -95, backgroundColor: '#292F5B' },
  authBrand: { color: C.white, fontSize: 44, fontFamily: Platform.select({ ios: 'AvenirNextRounded-DemiBold', android: 'sans-serif-rounded', default: 'Arial Rounded MT Bold' }), fontWeight: '900', letterSpacing: -3, marginBottom: 29 },
  authTitle: { color: C.white, fontSize: 37, lineHeight: 41, fontFamily: Platform.select({ ios: 'AvenirNextRounded-DemiBold', android: 'sans-serif-rounded', default: 'Arial Rounded MT Bold' }), fontWeight: '900', letterSpacing: -1.3, marginTop: 10 },
  authSubtitle: { color: C.muted, fontSize: 15, lineHeight: 23, marginTop: 13, marginBottom: 28 },
  authPanel: { borderRadius: 27, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, padding: 20 },
  authPanelTitle: { color: C.white, fontSize: 22, fontWeight: '800', marginBottom: 17 },
  authTabs: { flexDirection: 'row', gap: 8, marginBottom: 22 }, authTab: { flex: 1, borderRadius: 13, minHeight: 43, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: C.lime }, authTabActive: { backgroundColor: C.white }, authTabText: { color: C.white, fontWeight: '700' }, authTabTextActive: { color: C.deep },
  authContinue: { minHeight: 55, borderRadius: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12 }, authContinueText: { color: C.deep, fontWeight: '900', fontSize: 16 },
  authDivider: { color: C.muted, textAlign: 'center', fontSize: 10, fontWeight: '800', letterSpacing: 1.2, marginVertical: 18 },
  authSocialRow: { flexDirection: 'row', gap: 9 }, authSocial: { flex: 1, minHeight: 51, borderRadius: 14, borderWidth: 1, borderColor: C.line, backgroundColor: C.lime, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 }, authSocialSelected: { borderColor: C.orange }, authSocialLetter: { color: C.orange, fontSize: 20, fontWeight: '900' }, authMicrosoftMark: { color: C.orange, fontSize: 22 }, authSocialText: { color: C.white, fontSize: 13, fontWeight: '700' },
  authProviderNote: { color: C.muted, fontSize: 13, lineHeight: 19, marginBottom: 17 }, authDisclosure: { color: C.muted, fontSize: 11, lineHeight: 17, marginTop: 18 }, quizHint: { color: C.muted, fontSize: 12, lineHeight: 18, marginTop: 14 },
  currencyGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 }, currencyChip: { minWidth: 68, minHeight: 45, paddingHorizontal: 12, borderRadius: 13, borderWidth: 1, borderColor: C.line, backgroundColor: C.soft, justifyContent: 'center', alignItems: 'center' }, currencyChipSelected: { backgroundColor: C.white, borderColor: C.orange }, currencyChipText: { color: C.white, fontWeight: '800', fontSize: 13 }, currencyChipTextSelected: { color: C.deep }, familiarCost: { color: C.orange, fontSize: 12, fontWeight: '700', textAlign: 'right' },
  rateCard: { marginTop: 18, borderRadius: 18, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, padding: 17, gap: 8 }, rateTitle: { color: C.ink, fontSize: 17, fontWeight: '800' }, rateNote: { color: C.muted, fontSize: 12, lineHeight: 18 },
  header: { height: 64, paddingHorizontal: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: C.bg },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 8 }, brandText: { color: C.ink, fontSize: 24, fontWeight: '900', letterSpacing: -1.4 },
  modePill: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: C.soft, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 30 }, modeText: { color: C.green, fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  heroTitle: { color: C.ink, fontSize: 39, lineHeight: 43, fontWeight: '900', letterSpacing: -1.9, marginTop: 12 }, heroSub: { color: C.muted, fontSize: 15, lineHeight: 23, marginTop: 10, maxWidth: 310 },
  heroCard: { minHeight: 290, borderRadius: 28, padding: 22, overflow: 'hidden' }, heroTop: { flexDirection: 'row', alignItems: 'center', gap: 10 }, heroBubble: { width: 42, height: 42, borderRadius: 15, backgroundColor: C.lime, alignItems: 'center', justifyContent: 'center' }, heroSmall: { color: C.muted, fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }, heroCardTitle: { color: C.white, fontSize: 27, lineHeight: 30, fontWeight: '800', letterSpacing: -0.7, marginTop: 19, maxWidth: 260 }, heroCardBody: { color: C.muted, fontSize: 14, lineHeight: 20, marginTop: 9, maxWidth: 270 }, heroButton: { marginTop: 22, height: 50, borderRadius: 15, paddingHorizontal: 17, backgroundColor: C.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', zIndex: 2 }, heroButtonText: { color: C.deep, fontWeight: '800', fontSize: 14 }, heroDecorOne: { position: 'absolute', width: 230, height: 230, borderRadius: 115, borderColor: '#51689E', borderWidth: 1, right: -120, top: -60 }, heroDecorTwo: { position: 'absolute', width: 180, height: 180, borderRadius: 90, borderColor: '#51689E', borderWidth: 1, right: -80, top: -32 },
  homeActionList: { gap: 10 }, homeAction: { minHeight: 74, padding: 14, borderRadius: 20, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, flexDirection: 'row', alignItems: 'center', gap: 13 }, homeActionIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: C.lime, alignItems: 'center', justifyContent: 'center' }, homeActionTitle: { color: C.ink, fontSize: 16, fontWeight: '800' }, homeActionSub: { color: C.muted, fontSize: 12, lineHeight: 17, marginTop: 2 },
  journeyRow: { flexDirection: 'row', gap: 10 }, journeyItem: { flex: 1, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, padding: 12, borderRadius: 19 }, journeyIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center', marginBottom: 13 }, journeyTitle: { color: C.ink, fontWeight: '800', fontSize: 14 }, journeySub: { color: C.muted, fontSize: 11, marginTop: 3 },
  inlineTop: { flexDirection: 'row', alignItems: 'center', gap: 10 }, smallIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: C.lime, alignItems: 'center', justifyContent: 'center' }, inlineTag: { color: C.green, fontSize: 10, fontWeight: '800', letterSpacing: 1.2 }, featureTitle: { color: C.ink, fontWeight: '800', fontSize: 22, letterSpacing: -0.5, marginTop: 14 }, featureBody: { color: C.muted, lineHeight: 21, fontSize: 14, marginTop: 7, marginBottom: 18 }, demoNote: { color: C.muted, fontSize: 11, lineHeight: 17, marginTop: 17, marginBottom: 4 },
  backRow: { height: 45, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }, backButton: { width: 40, height: 40, borderRadius: 14, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, alignItems: 'center', justifyContent: 'center' }, progressText: { color: C.muted, fontSize: 11, fontWeight: '800', letterSpacing: 1.2 }, progressTrack: { height: 6, backgroundColor: C.line, borderRadius: 5, overflow: 'hidden' }, progressFill: { height: 6, backgroundColor: C.green, borderRadius: 5 }, pageTitle: { color: C.ink, fontSize: 34, lineHeight: 38, fontWeight: '900', letterSpacing: -1.35, marginTop: 11 }, pageSub: { color: C.muted, fontSize: 15, lineHeight: 22, marginTop: 9 }, choiceList: { gap: 10 }, choice: { minHeight: 64, paddingHorizontal: 15, paddingVertical: 13, borderRadius: 18, backgroundColor: C.soft, borderWidth: 1.5, borderColor: C.line, flexDirection: 'row', alignItems: 'center', gap: 12 }, choiceSelected: { borderColor: C.green, backgroundColor: C.lime }, choiceIcon: { width: 37, height: 37, borderRadius: 13, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' }, choiceLabel: { color: C.ink, fontSize: 15, fontWeight: '700' }, choiceDetail: { color: C.muted, fontSize: 11, marginTop: 4 }, quizFoot: { textAlign: 'center', color: C.muted, fontSize: 11, marginTop: 16 }, link: { color: C.green, fontWeight: '800', fontSize: 13 },
  areaCard: { backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, borderRadius: 22, overflow: 'hidden', marginBottom: 13 }, areaArt: { height: 100, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, areaArtCircle: { width: 65, height: 65, borderRadius: 33, backgroundColor: '#FFE8CA55', alignItems: 'center', justifyContent: 'center' }, areaArtZone: { color: C.green, fontWeight: '800', fontSize: 12 }, matchBadge: { color: C.green, fontSize: 10, fontWeight: '900', letterSpacing: 1.2 }, areaName: { color: C.ink, fontSize: 24, fontWeight: '900', letterSpacing: -0.5, marginTop: 8, marginBottom: 5 }, muted: { color: C.muted, fontSize: 13, lineHeight: 19 }, areaFacts: { marginTop: 14, flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, factText: { color: C.green, fontSize: 12, fontWeight: '700' }, areaHero: { height: 185, borderRadius: 26, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }, areaHeroCircle: { width: 104, height: 104, borderRadius: 52, backgroundColor: '#FFE8CA55', alignItems: 'center', justifyContent: 'center' }, areaHeroLabel: { color: C.green, fontSize: 10, fontWeight: '900', letterSpacing: 1.5, marginTop: 12 },
  costRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }, costValue: { color: C.ink, fontSize: 14, fontWeight: '700' }, divider: { height: 1, backgroundColor: C.line, marginVertical: 13 }, totalLabel: { color: C.ink, fontWeight: '800', fontSize: 14 }, totalValue: { color: C.green, fontSize: 21, fontWeight: '900' }, compareName: { color: C.ink, fontSize: 19, fontWeight: '800', letterSpacing: -0.3 }, compareZone: { color: C.green, fontSize: 12, fontWeight: '800' },
  inputLabel: { color: C.ink, fontSize: 13, fontWeight: '800', marginBottom: 8 }, input: { borderWidth: 1, borderColor: C.line, borderRadius: 16, backgroundColor: C.soft, minHeight: 55, paddingHorizontal: 15, color: C.ink, fontSize: 14, marginBottom: 18 }, error: { color: '#FF9A8C', marginBottom: 12, fontSize: 13 }, emptyIcon: { width: 50, height: 50, backgroundColor: C.soft, borderRadius: 17, justifyContent: 'center', alignItems: 'center' }, reportBody: { color: C.ink, fontSize: 14, lineHeight: 21 },
  progressNumber: { color: C.green, fontSize: 27, fontWeight: '900' }, taskRow: { backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, borderRadius: 18, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 11, padding: 14 }, taskIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' }, taskTitle: { color: C.ink, fontSize: 14, fontWeight: '800' }, taskSub: { color: C.muted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  kitCard: { borderWidth: 1, borderColor: C.line, backgroundColor: C.soft, borderRadius: 22, padding: 18, marginBottom: 12 }, kitIcon: { width: 45, height: 45, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }, circleArt: { height: 200, borderRadius: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }, circlePerson: { width: 79, height: 79, borderRadius: 40, backgroundColor: C.white, borderWidth: 3, borderColor: C.white, justifyContent: 'center', alignItems: 'center' },
  nav: { height: 70, flexDirection: 'row', backgroundColor: C.soft, borderTopWidth: 1, borderTopColor: C.line, paddingHorizontal: 12 }, navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4 }, navText: { color: C.muted, fontSize: 10, fontWeight: '600' },
});
