# Gates: Nooks iOS prototype

OWNS: App.tsx, src/**, .vscode/**, assets/**, package.json, package-lock.json, app.json, tsconfig.json, README.md, GATES.md

Scope: An editable Expo iOS prototype with connected client and rep journeys for Nooks.

Latest addition: automatic exchange-rate lookup for the selected destination and familiar currencies.

- [x] G0f: the rent budget is entered in the familiar currency and immediately converted to destination currency
  CHECK: npm run test:fx and browser preview
  EXPECT: currency selection and budget input on step 7, with a destination-currency equivalent used for matching
  EVIDENCE: In the VS Code browser preview, selecting USD and entering 1325 showed about GBP 1000. Switching to UZS and entering 16000000 showed about GBP 1021. The latest npm run verify passed, including the conversion test and iOS export.

- [x] G0e: the currency screen loads a reference rate automatically and shows its date, with a safe unavailable state
  CHECK: npm run test:fx and browser preview
  EXPECT: no manual rate field; automatic rate or clear unavailable state
  EVIDENCE: VS Code browser preview showed 1 GBP ≈ 1.3254 USD, dated 2026-09-27, without any rate input. The test covers valid, malformed and invalid currency pairs. The UI shows destination-currency costs if the request fails.

- [x] G0c: the supplied logo appears on registration and in the app header, with a matching installed app icon
  EVIDENCE: Browser preview exposed the same Nooks logo image on both screens; the source screenshot is kept unchanged in assets. Expo config points to an opaque square logo adaptation for the launcher.

- [x] G0d: the questionnaire asks origin country, familiar currency and solo versus shared housing, then opens the main choice screen
  EVIDENCE: Live browser walkthrough selected Uzbekistan, UZS, and living alone; after step 10 it opened the personalised home with neighbourhoods, Move, First night, Settle and Circle actions.

- [x] G0: registration is the first screen, with email, phone, Google and Microsoft choices, followed by the quiz
  EVIDENCE: VS Code integrated browser opened directly on the registration screen. Entering a demo email and pressing Continue opened quiz step 1. The UI discloses that real authentication is not connected.

- [x] G0b: quiz asks country, then city, then university from a list or custom entry
  EVIDENCE: In the live browser preview, choosing United Kingdom showed its city list; choosing London showed its university list at step 3. Custom entry is available at each step.

- [x] G1: the client can complete the neighbourhood quiz and see ranked areas with an itemised monthly estimate
  CHECK: npm run test:logic
  EXPECT: logic checks passed
  EVIDENCE: Direct run of npm run test:logic passed. The quiz has ten steps. Ranking and cost rows remain covered by logic checks.

- [x] G2: the project type checks and bundles for iOS
  CHECK: npm run verify
  EXPECT: project verification passed
  EVIDENCE: EXPO_NO_TELEMETRY=1 npm run verify passed after the automatic exchange-rate change, including typecheck, logic and rate tests, and iOS export.

- [x] G3: booking and rep flows are implemented with visible local state and clear demo limitations
  EVIDENCE: Source review verified booking creation, rep acceptance, report submission, client status display, and demo disclosures in App.tsx and README.md.

- [x] G4: the project opens in Visual Studio Code
  EVIDENCE: Visual Studio Code showed the nooks-ios Explorer and README.md in its window.
