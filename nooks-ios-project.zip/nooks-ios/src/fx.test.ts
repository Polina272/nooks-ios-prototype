import assert from 'node:assert/strict';
import { budgetInDestination, fetchExchangeRate } from './fx';

async function main() {
  const validResponse = async () => new Response(JSON.stringify({ date: '2026-09-26', base: 'GBP', quote: 'USD', rate: 1.35 }), { status: 200 });
  const quote = await fetchExchangeRate('gbp', 'usd', undefined, validResponse as typeof fetch);
  assert.deepEqual(quote, { base: 'GBP', quote: 'USD', rate: 1.35, date: '2026-09-26' });

  const invalidResponse = async () => new Response(JSON.stringify({ date: '2026-09-26', base: 'GBP', quote: 'USD', rate: 0 }), { status: 200 });
  await assert.rejects(fetchExchangeRate('GBP', 'USD', undefined, invalidResponse as typeof fetch), /Invalid exchange-rate response/);
  await assert.rejects(fetchExchangeRate('GBP', 'US', undefined, validResponse as typeof fetch), /Invalid currency pair/);

  assert.equal(budgetInDestination(1350, 1.35), 1000);
  assert.equal(budgetInDestination(1350, 0), 0);
  assert.equal(budgetInDestination(-20, 1.35), 0);

  console.log('exchange-rate checks passed');
}

main().catch(error => { console.error(error); process.exitCode = 1; });
