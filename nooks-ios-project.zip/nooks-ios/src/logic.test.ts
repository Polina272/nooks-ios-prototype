import assert from 'node:assert/strict';
import { areas, defaultAnswers, money, monthlyCost, rankAreas, type Area } from './logic';

const londonAnswers = { ...defaultAnswers, city: 'London', destination: 'imperial' as const, budget: 1400 };

const fulham = areas.find(area => area.id === 'fulham');
assert.ok(fulham);

const fourDay = monthlyCost(fulham, londonAnswers);
assert.equal(fourDay.total, fourDay.rent + fourDay.bills + fourDay.transport + fourDay.councilTax);
assert.equal(fourDay.councilTax, 0);
assert.ok(fourDay.transport > 0);

const twoDay = monthlyCost(fulham, { ...londonAnswers, daysPerWeek: 2 });
assert.ok(twoDay.transport < fourDay.transport);

const solo = monthlyCost(fulham, { ...londonAnswers, homeType: 'solo' });
assert.ok(solo.total > fourDay.total);

const working = monthlyCost(fulham, { ...londonAnswers, destination: 'other' });
assert.ok(working.councilTax > 0);

const ranked = rankAreas(londonAnswers);
assert.equal(ranked.length, areas.length);
assert.equal(new Set(ranked.map(item => item.area.id)).size, areas.length);
assert.ok(ranked.every((item, index) => index === 0 || ranked[index - 1].score >= item.score));
assert.equal(rankAreas({ ...londonAnswers, destination: 'other' })[0].commute, null);
assert.equal(rankAreas({ ...londonAnswers, city: 'Paris' }).length, 0);
assert.equal(rankAreas({ ...londonAnswers, city: 'london' }).length, areas.length);

const custom: Area = {
  ...fulham, id: 'custom-tokyo', city: 'Tokyo', name: 'Shibuya', zone: 'Your estimate',
  roomRent: 140000, soloRent: 140000, farePerTrip: 230, manualCommute: 22,
  billsShared: 12000, billsSolo: 12000, localTax: 0, food: [], lifestyle: [],
};
const tokyo = rankAreas({ ...defaultAnswers, city: 'Tokyo', currency: 'JPY', budget: 150000 }, [...areas, custom]);
assert.equal(tokyo.length, 1);
assert.equal(tokyo[0].area.name, 'Shibuya');
assert.equal(tokyo[0].commute, 22);
assert.equal(tokyo[0].cost.bills, 12000);
assert.equal(money(1234, 'JPY'), 'JPY 1,234');

console.log('logic checks passed');
