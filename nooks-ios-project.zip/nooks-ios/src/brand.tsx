import React from 'react';
import { Image, View } from 'react-native';

const logo = require('../assets/nooks-logo-source.png');

// Display the supplied logo screenshot at its original proportions. The View
// clips only the surrounding screenshot background; the source file is intact.
export function BrandLogo({ size }: { size: number }) {
  const scale = size / 189;
  return <View style={{ width: size, height: size, overflow: 'hidden', borderRadius: size * 0.25 }}>
    <Image
      source={logo}
      accessibilityLabel="Nooks logo"
      style={{ position: 'absolute', width: 280 * scale, height: 272 * scale, left: -36 * scale, top: -40 * scale }}
    />
  </View>;
}
