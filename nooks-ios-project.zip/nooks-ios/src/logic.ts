export type Destination = 'imperial' | 'ucl' | 'kings' | 'lse' | 'other';
export type FoodPreference = 'halal' | 'international' | 'none';
export type Lifestyle = 'parks' | 'fitness' | 'nightlife' | 'quiet';
export type HomeType = 'shared' | 'solo';

export type Answers = {
  originCountry: string;
  country: string;
  city: string;
  university: string;
  currency: string;
  preferredCurrency: string;
  exchangeRate: number;
  destination: Destination;
  customDestination: string;
  budget: number;
  daysPerWeek: number;
  food: FoodPreference;
  lifestyle: Lifestyle;
  homeType: HomeType;
};

export type Area = {
  id: string;
  city: string;
  name: string;
  zone: string;
  character: string;
  roomRent: number;
  soloRent: number;
  farePerTrip: number;
  manualCommute?: number;
  billsShared?: number;
  billsSolo?: number;
  localTax?: number;
  commute: Record<Exclude<Destination, 'other'>, number>;
  food: FoodPreference[];
  lifestyle: Lifestyle[];
  accent: string;
  icon: string;
};

export const defaultAnswers: Answers = {
  originCountry: '',
  country: '',
  city: '',
  university: '',
  currency: 'GBP',
  preferredCurrency: 'GBP',
  exchangeRate: 1,
  destination: 'other',
  customDestination: '',
  budget: 0,
  daysPerWeek: 4,
  food: 'none',
  lifestyle: 'parks',
  homeType: 'shared',
};

// Illustrative seed figures for a clickable prototype, not live listings or TfL fares.
export const areas: Area[] = [
  {
    id: 'fulham', city: 'London', name: 'Fulham', zone: 'Zone 2',
    character: 'Leafy streets, riverside walks and easy west London connections.',
    roomRent: 1350, soloRent: 2350, farePerTrip: 3.1,
    commute: { imperial: 24, ucl: 36, kings: 39, lse: 34 },
    food: ['halal', 'international'], lifestyle: ['parks', 'fitness', 'quiet'],
    accent: '#DEECDF', icon: 'leaf-outline',
  },
  {
    id: 'stratford', city: 'London', name: 'Stratford', zone: 'Zone 2/3',
    character: 'Fast connections, shopping and a lively new neighbourhood.',
    roomRent: 1170, soloRent: 2050, farePerTrip: 3.5,
    commute: { imperial: 48, ucl: 29, kings: 34, lse: 30 },
    food: ['halal', 'international'], lifestyle: ['fitness', 'nightlife', 'parks'],
    accent: '#E9E4FA', icon: 'sparkles-outline',
  },
  {
    id: 'acton', city: 'London', name: 'Acton', zone: 'Zone 3',
    character: 'More space for your budget, local cafés and quieter evenings.',
    roomRent: 1080, soloRent: 1850, farePerTrip: 3.5,
    commute: { imperial: 32, ucl: 38, kings: 44, lse: 41 },
    food: ['international'], lifestyle: ['parks', 'quiet', 'fitness'],
    accent: '#FBE8D3', icon: 'sunny-outline',
  },
  {
    id: 'greenwich', city: 'London', name: 'Greenwich', zone: 'Zone 2/3',
    character: 'Historic streets, a huge park and a slower pace by the river.',
    roomRent: 1200, soloRent: 2100, farePerTrip: 3.5,
    commute: { imperial: 51, ucl: 43, kings: 33, lse: 35 },
    food: ['international'], lifestyle: ['parks', 'quiet'],
    accent: '#DDEDF0', icon: 'compass-outline',
  },
];

export function monthlyCost(area: Area, answers: Answers) {
  const rent = answers.homeType === 'shared' ? area.roomRent : area.soloRent;
  const bills = answers.homeType === 'shared' ? (area.billsShared ?? 125) : (area.billsSolo ?? 230);
  const transport = Math.round(area.farePerTrip * 2 * answers.daysPerWeek * 4.33);
  const councilTax = area.localTax ?? (area.city === 'London' && answers.destination === 'other'
    ? answers.homeType === 'shared' ? 100 : 170
    : 0);
  const total = rent + bills + transport + councilTax;
  return { rent, bills, transport, councilTax, total };
}

export function getCommute(area: Area, answers: Answers): number | null {
  if (area.manualCommute !== undefined) return area.manualCommute;
  return answers.destination === 'other' ? null : area.commute[answers.destination];
}

export function rankAreas(answers: Answers, candidates: Area[] = areas) {
  return candidates.filter(area => area.city.trim().toLocaleLowerCase() === answers.city.trim().toLocaleLowerCase()).map(area => {
    const cost = monthlyCost(area, answers);
    const commute = getCommute(area, answers);
    const overBudget = Math.max(0, cost.rent - answers.budget);
    const score = 100
      - Math.min(45, (overBudget / Math.max(answers.budget, 1)) * 45)
      - (commute === null ? 0 : commute * 0.45)
      - (cost.total / Math.max(answers.budget, 1)) * 10
      + (answers.food !== 'none' && area.food.includes(answers.food) ? 9 : 0)
      + (area.lifestyle.includes(answers.lifestyle) ? 12 : 0);
    return { area, cost, commute, score };
  }).sort((a, b) => b.score - a.score);
}

export function money(amount: number, currency = 'GBP') {
  const symbol: Record<string, string> = { GBP: '£', USD: '$', EUR: '€', UZS: 'soʻm ' };
  const prefix = symbol[currency.toUpperCase()] ?? `${currency.toUpperCase()} `;
  return `${prefix}${amount.toLocaleString('en-GB')}`;
}
