// Starter catalog for the prototype. Every step also accepts a custom answer.
export const places = [
  { country: 'United Kingdom', currency: 'GBP', cities: [
    { city: 'London', universities: ['Imperial College London', 'University College London (UCL)', "King’s College London", 'London School of Economics (LSE)', 'Queen Mary University of London'] },
    { city: 'Manchester', universities: ['University of Manchester', 'Manchester Metropolitan University', 'University of Salford'] },
    { city: 'Edinburgh', universities: ['University of Edinburgh', 'Heriot-Watt University', 'Edinburgh Napier University'] },
  ] },
  { country: 'United States', currency: 'USD', cities: [
    { city: 'New York', universities: ['Columbia University', 'New York University', 'The New School'] },
    { city: 'Boston', universities: ['Harvard University', 'Massachusetts Institute of Technology', 'Boston University', 'Northeastern University'] },
    { city: 'San Francisco', universities: ['University of San Francisco', 'San Francisco State University', 'University of California, San Francisco'] },
  ] },
  { country: 'Canada', currency: 'CAD', cities: [
    { city: 'Toronto', universities: ['University of Toronto', 'Toronto Metropolitan University', 'York University'] },
    { city: 'Vancouver', universities: ['University of British Columbia', 'Simon Fraser University'] },
    { city: 'Montréal', universities: ['McGill University', 'Concordia University', 'Université de Montréal'] },
  ] },
  { country: 'Australia', currency: 'AUD', cities: [
    { city: 'Sydney', universities: ['University of Sydney', 'UNSW Sydney', 'University of Technology Sydney'] },
    { city: 'Melbourne', universities: ['University of Melbourne', 'Monash University', 'RMIT University'] },
  ] },
  { country: 'Germany', currency: 'EUR', cities: [
    { city: 'Berlin', universities: ['Humboldt University of Berlin', 'Freie Universität Berlin', 'Technische Universität Berlin'] },
    { city: 'Munich', universities: ['Ludwig Maximilian University of Munich', 'Technical University of Munich'] },
  ] },
  { country: 'France', currency: 'EUR', cities: [
    { city: 'Paris', universities: ['Sorbonne University', 'Université Paris Cité', 'Sciences Po'] },
    { city: 'Lyon', universities: ['Université Claude Bernard Lyon 1', 'Université Lumière Lyon 2'] },
  ] },
  { country: 'Netherlands', currency: 'EUR', cities: [
    { city: 'Amsterdam', universities: ['University of Amsterdam', 'Vrije Universiteit Amsterdam'] },
    { city: 'Rotterdam', universities: ['Erasmus University Rotterdam'] },
  ] },
  { country: 'Japan', currency: 'JPY', cities: [
    { city: 'Tokyo', universities: ['The University of Tokyo', 'Waseda University', 'Keio University'] },
    { city: 'Kyoto', universities: ['Kyoto University', 'Ritsumeikan University'] },
  ] },
  { country: 'South Korea', currency: 'KRW', cities: [
    { city: 'Seoul', universities: ['Seoul National University', 'Yonsei University', 'Korea University'] },
  ] },
  { country: 'Singapore', currency: 'SGD', cities: [
    { city: 'Singapore', universities: ['National University of Singapore', 'Nanyang Technological University', 'Singapore Management University'] },
  ] },
  { country: 'United Arab Emirates', currency: 'AED', cities: [
    { city: 'Dubai', universities: ['University of Dubai', 'American University in Dubai', 'Middlesex University Dubai'] },
    { city: 'Abu Dhabi', universities: ['New York University Abu Dhabi', 'Khalifa University'] },
  ] },
  { country: 'Uzbekistan', currency: 'UZS', cities: [
    { city: 'Tashkent', universities: ['National University of Uzbekistan', 'Westminster International University in Tashkent', 'Tashkent State Technical University'] },
  ] },
] as const;

export function citiesFor(country: string): readonly { city: string; universities: readonly string[] }[] {
  return places.find(item => item.country.toLowerCase() === country.trim().toLowerCase())?.cities ?? [];
}

export function universitiesFor(country: string, city: string): readonly string[] {
  return citiesFor(country).find(item => item.city.toLowerCase() === city.trim().toLowerCase())?.universities ?? [];
}

export function currencyFor(country: string): string {
  return places.find(item => item.country.toLowerCase() === country.trim().toLowerCase())?.currency ?? '';
}
