import React from 'react';
import { Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export const C = {
  bg: '#10224F', white: '#FFE8CA', ink: '#FFE8CA', muted: '#A9B7D5',
  green: '#FF9A70', deep: '#10224F', lime: '#263D73', line: '#344A7B',
  orange: '#FFB86B', soft: '#1A3268', purple: '#343B70',
};

export function Icon({ name, size = 20, color = C.ink }: { name: keyof typeof Ionicons.glyphMap; size?: number; color?: string }) {
  return <Ionicons name={name} size={size} color={color} />;
}

export function Button({ title, onPress, secondary = false, small = false, disabled = false, icon }: {
  title: string; onPress: () => void; secondary?: boolean; small?: boolean; disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [
    styles.button, secondary && styles.secondary, small && styles.small,
    disabled && { opacity: 0.45 }, pressed && { opacity: 0.8 },
  ]}>
    <Text style={[styles.buttonText, secondary && styles.secondaryText, small && { fontSize: 14 }]}>{title}</Text>
    {icon && <Icon name={icon} size={small ? 16 : 18} color={secondary ? C.orange : C.deep} />}
  </Pressable>;
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Eyebrow({ children }: { children: React.ReactNode }) {
  return <Text style={styles.eyebrow}>{children}</Text>;
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return <View style={styles.sectionRow}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {action && onAction && <Pressable onPress={onAction}><Text style={styles.sectionAction}>{action}</Text></Pressable>}
  </View>;
}

export function Row({ icon, title, subtitle, onPress, trailing }: {
  icon: keyof typeof Ionicons.glyphMap; title: string; subtitle?: string; onPress?: () => void; trailing?: string;
}) {
  return <Pressable onPress={onPress} disabled={!onPress} style={styles.row}>
    <View style={styles.rowIcon}><Icon name={icon} size={20} color={C.green} /></View>
    <View style={{ flex: 1 }}><Text style={styles.rowTitle}>{title}</Text>{subtitle && <Text style={styles.rowSub}>{subtitle}</Text>}</View>
    {trailing ? <Text style={styles.rowTrailing}>{trailing}</Text> : onPress ? <Icon name="chevron-forward" size={18} color={C.muted} /> : null}
  </Pressable>;
}

const styles = StyleSheet.create({
  button: { minHeight: 54, borderRadius: 17, backgroundColor: C.green, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  secondary: { backgroundColor: C.soft, borderWidth: 1, borderColor: C.line },
  small: { minHeight: 43, borderRadius: 13, paddingHorizontal: 15 },
  buttonText: { color: C.deep, fontSize: 16, fontWeight: '700' },
  secondaryText: { color: C.white },
  card: { backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, borderRadius: 24, padding: 20 },
  eyebrow: { color: C.green, fontSize: 11, fontWeight: '800', letterSpacing: 1.8, textTransform: 'uppercase' },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  sectionTitle: { color: C.ink, fontSize: 21, fontWeight: '800', letterSpacing: -0.5 },
  sectionAction: { color: C.green, fontSize: 13, fontWeight: '700' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingVertical: 10 },
  rowIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' },
  rowTitle: { color: C.ink, fontSize: 15, fontWeight: '700' },
  rowSub: { color: C.muted, fontSize: 12, marginTop: 3 },
  rowTrailing: { color: C.green, fontSize: 13, fontWeight: '700' },
});
