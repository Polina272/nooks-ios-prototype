export type ExchangeRateQuote = { base: string; quote: string; rate: number; date: string };

const codePattern = /^[A-Z]{3}$/;

export function budgetInDestination(amount: number, destinationToFamiliarRate: number): number {
  if (!Number.isFinite(amount) || amount <= 0 || !Number.isFinite(destinationToFamiliarRate) || destinationToFamiliarRate <= 0) return 0;
  return Math.round(amount / destinationToFamiliarRate);
}

export async function fetchExchangeRate(base: string, quote: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<ExchangeRateQuote> {
  const from = base.toUpperCase();
  const to = quote.toUpperCase();
  if (!codePattern.test(from) || !codePattern.test(to) || from === to) throw new Error('Invalid currency pair');

  const response = await request(`https://api.frankfurter.dev/v2/rate/${from.toLowerCase()}/${to.toLowerCase()}`, { signal });
  if (!response.ok) throw new Error(`Exchange-rate service returned ${response.status}`);
  const data: unknown = await response.json();
  if (!data || typeof data !== 'object') throw new Error('Invalid exchange-rate response');
  const rate = data as Partial<ExchangeRateQuote>;
  if (rate.base?.toUpperCase() !== from || rate.quote?.toUpperCase() !== to ||
      typeof rate.rate !== 'number' || !Number.isFinite(rate.rate) || rate.rate <= 0 ||
      typeof rate.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(rate.date)) {
    throw new Error('Invalid exchange-rate response');
  }
  return { base: from, quote: to, rate: rate.rate, date: rate.date };
}
